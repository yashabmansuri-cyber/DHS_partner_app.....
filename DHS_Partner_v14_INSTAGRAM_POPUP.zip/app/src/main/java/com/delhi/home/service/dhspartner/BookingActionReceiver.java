package com.delhi.home.service.dhspartner;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class BookingActionReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        Intent i = new Intent(context, PartnerForegroundService.class);
        i.setAction(intent.getAction());
        i.putExtra(PartnerForegroundService.EXTRA_BOOKING_ID, intent.getStringExtra(PartnerForegroundService.EXTRA_BOOKING_ID));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(i);
        else context.startService(i);
    }
}
