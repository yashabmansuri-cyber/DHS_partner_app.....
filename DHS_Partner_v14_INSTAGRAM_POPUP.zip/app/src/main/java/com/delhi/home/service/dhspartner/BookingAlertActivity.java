package com.delhi.home.service.dhspartner;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class BookingAlertActivity extends Activity {
    private String bookingId = "";
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Window w = getWindow();
        w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        if (android.os.Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        }
        w.setStatusBarColor(Color.TRANSPARENT);
        w.setNavigationBarColor(Color.TRANSPARENT);
        if (android.os.Build.VERSION.SDK_INT >= 21) w.getDecorView().setSystemUiVisibility(0);
        bookingId = getIntent().getStringExtra(PartnerForegroundService.EXTRA_BOOKING_ID);
        String customer = getIntent().getStringExtra(PartnerForegroundService.EXTRA_CUSTOMER);
        String service = getIntent().getStringExtra(PartnerForegroundService.EXTRA_SERVICE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER);
        root.setPadding(28,28,28,28); root.setBackgroundColor(0x99000000);
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(28,24,28,24);
        GradientDrawable bg = new GradientDrawable(); bg.setColor(Color.WHITE); bg.setCornerRadius(32); card.setBackground(bg);
        TextView title = new TextView(this); title.setText("🔔  NEW DHS BOOKING"); title.setTextSize(20); title.setTextColor(0xFF061B46); title.setGravity(Gravity.CENTER); title.setTypeface(null,1);
        TextView details = new TextView(this); details.setText("\nCustomer: " + safe(customer) + "\nService: " + safe(service)); details.setTextSize(16); details.setTextColor(0xFF17243C); details.setPadding(0,10,0,18);
        Button accept = new Button(this); accept.setText("ACCEPT BOOKING"); accept.setTextSize(16); accept.setAllCaps(false);
        Button reject = new Button(this); reject.setText("Reject"); reject.setAllCaps(false);
        card.addView(title); card.addView(details); card.addView(accept,new LinearLayout.LayoutParams(-1,60)); card.addView(reject,new LinearLayout.LayoutParams(-1,55));
        root.addView(card,new LinearLayout.LayoutParams(-1,-2)); setContentView(root);
        accept.setOnClickListener(v -> finishWith(PartnerForegroundService.ACTION_ACCEPT));
        reject.setOnClickListener(v -> finishWith(PartnerForegroundService.ACTION_REJECT));
    }
    private String safe(String s){return s==null||s.isEmpty()?"Customer":s;}
    private void finishWith(String action){
        Intent i=new Intent(this,PartnerForegroundService.class); i.setAction(action); i.putExtra(PartnerForegroundService.EXTRA_BOOKING_ID,bookingId);
        if(android.os.Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);
        finish();
    }
    @Override protected void onDestroy(){super.onDestroy();}
}
