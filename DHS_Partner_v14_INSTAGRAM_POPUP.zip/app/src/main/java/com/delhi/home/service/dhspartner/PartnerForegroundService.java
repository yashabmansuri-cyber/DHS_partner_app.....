package com.delhi.home.service.dhspartner;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Native foreground service used while a DHS Partner is online. */
public class PartnerForegroundService extends Service implements LocationListener {
    public static final String ACTION_START = "com.delhi.home.service.dhspartner.action.START";
    public static final String ACTION_STOP = "com.delhi.home.service.dhspartner.action.STOP";
    public static final String ACTION_UPDATE_AUTH = "com.delhi.home.service.dhspartner.action.UPDATE_AUTH";
    public static final String ACTION_ACCEPT = "com.delhi.home.service.dhspartner.action.ACCEPT";
    public static final String ACTION_REJECT = "com.delhi.home.service.dhspartner.action.REJECT";
    public static final String EXTRA_BOOKING_ID = "bookingId";
    public static final String EXTRA_CUSTOMER = "customer";
    public static final String EXTRA_SERVICE = "service";
    public static final String EXTRA_TOKEN = "idToken";
    public static final String EXTRA_UID = "uid";
    public static final String EXTRA_EMAIL = "email";

    private static final String CHANNEL_ID = "dhs_partner_online";
    private static final String BOOKING_CHANNEL_ID = "dhs_partner_bookings";
    private static final int NOTIFICATION_ID = 4201;
    private static final int BOOKING_NOTIFICATION_ID = 4202;
    private static final long POLL_MS = 2500L;
    private static final String PROJECT = "dhs-delhi-home-service";

    private LocationManager locationManager;
    private NotificationManager notificationManager;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Set<String> seenBookings = new HashSet<>();
    private String idToken = "";
    private String uid = "";
    private String email = "";
    private boolean running = false;
    private MediaPlayer alertPlayer;
    private Vibrator vibrator;
    private WindowManager windowManager;
    private View bookingOverlay;
    private String activeBookingId = "";

    private final Runnable poller = new Runnable() {
        @Override public void run() {
            if (!running || idToken.isEmpty() || uid.isEmpty()) return;
            executor.execute(() -> pollBookings());
            handler.postDelayed(this, POLL_MS);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        createNotificationChannels();
        vibrator = Build.VERSION.SDK_INT >= 31
                ? ((VibratorManager) getSystemService(VIBRATOR_MANAGER_SERVICE)).getDefaultVibrator()
                : (Vibrator) getSystemService(VIBRATOR_SERVICE);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopTracking();
            stopBookingAlert();
            running = false;
            handler.removeCallbacks(poller);
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        if (intent != null) {
            String token = intent.getStringExtra(EXTRA_TOKEN);
            String inUid = intent.getStringExtra(EXTRA_UID);
            String inEmail = intent.getStringExtra(EXTRA_EMAIL);
            if (token != null && !token.isEmpty()) idToken = token;
            if (inUid != null && !inUid.isEmpty()) uid = inUid;
            if (inEmail != null) email = inEmail;
            if (ACTION_ACCEPT.equals(action) || ACTION_REJECT.equals(action)) {
                String bid = intent.getStringExtra(EXTRA_BOOKING_ID);
                if (bid != null && !bid.isEmpty()) {
                    stopBookingAlert();
                    final String status = ACTION_ACCEPT.equals(action) ? "ACCEPTED" : "REJECTED";
                    executor.execute(() -> updateBooking(bid, status));
                }
            }
        }

        running = true;
        startForeground(NOTIFICATION_ID, buildOnlineNotification());
        startTracking();
        handler.removeCallbacks(poller);
        handler.post(poller);
        return START_STICKY;
    }

    public static void putAuth(Intent i, String token, String uid, String email) {
        i.putExtra(EXTRA_TOKEN, token == null ? "" : token);
        i.putExtra(EXTRA_UID, uid == null ? "" : uid);
        i.putExtra(EXTRA_EMAIL, email == null ? "" : email);
    }

    private void createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel online = new NotificationChannel(
                    CHANNEL_ID, "DHS Partner Online", NotificationManager.IMPORTANCE_LOW);
            online.setDescription("Persistent notification while the DHS Partner is online.");
            online.setShowBadge(false);
            notificationManager.createNotificationChannel(online);

            NotificationChannel booking = new NotificationChannel(
                    BOOKING_CHANNEL_ID, "DHS New Bookings", NotificationManager.IMPORTANCE_HIGH);
            booking.setDescription("Urgent new booking alerts for DHS Partners.");
            booking.setSound(null, new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
            booking.enableVibration(true);
            booking.setVibrationPattern(new long[]{0, 600, 120, 600, 120, 1000});
            booking.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            notificationManager.createNotificationChannel(booking);
        }
    }

    private PendingIntent activityIntent() {
        Intent launch = new Intent(this, MainActivity.class);
        launch.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(this, 4203, launch,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
    }

    private Notification buildOnlineNotification() {
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("DHS Partner")
                .setContentText("You are online • Ready for bookings")
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(NotificationCompat.CATEGORY_SERVICE)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setContentIntent(activityIntent())
                .build();
    }

    private void startTracking() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return;
        try {
            locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
            if (locationManager == null) return;
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER))
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000L, 10f, this);
            if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER))
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 10000L, 25f, this);
        } catch (Exception ignored) {}
    }

    private void stopTracking() {
        if (locationManager != null) try { locationManager.removeUpdates(this); } catch (Exception ignored) {}
    }

    private void pollBookings() {
        try {
            JSONArray docs = runStructuredQuery("workeruid", uid);
            if (docs.length() == 0) docs = runStructuredQuery("partnerId", uid);
            for (int i = 0; i < docs.length(); i++) {
                JSONObject doc = docs.getJSONObject(i);
                String name = doc.optString("__name", "");
                String id = name.substring(name.lastIndexOf('/') + 1);
                JSONObject fields = doc.optJSONObject("fields");
                if (fields == null || id.isEmpty()) continue;
                String state = fieldString(fields, "partnerStatus", fieldString(fields, "Stuts", fieldString(fields, "bookingStatus", "NEW"))).toUpperCase();
                if (!("NEW".equals(state) || "PENDING_ACCEPT".equals(state))) continue;
                if (seenBookings.add(id)) {
                    String customer = fieldString(fields, "costumername", fieldString(fields, "customerName", "Customer"));
                    String service = fieldString(fields, "service", fieldString(fields, "serviceType", "New DHS Booking"));
                    showBookingAlert(id, customer, service);
                }
            }
        } catch (Exception ignored) {}
    }

    private JSONArray runStructuredQuery(String field, String value) throws Exception {
        URL url = new URL("https://firestore.googleapis.com/v1/projects/" + PROJECT + "/databases/(default)/documents:runQuery");
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(7000); c.setReadTimeout(7000);
        c.setRequestProperty("Authorization", "Bearer " + idToken);
        c.setRequestProperty("Content-Type", "application/json");
        c.setDoOutput(true);
        JSONObject valueObj = new JSONObject().put("stringValue", value);
        JSONObject fieldFilter = new JSONObject().put("field", new JSONObject().put("fieldPath", field))
                .put("op", "EQUAL").put("value", valueObj);
        JSONObject query = new JSONObject().put("from", new JSONArray().put(new JSONObject().put("collectionId", "partnerJobs")))
                .put("where", new JSONObject().put("fieldFilter", fieldFilter))
                .put("limit", 20);
        JSONObject body = new JSONObject().put("structuredQuery", query);
        try (OutputStream os = c.getOutputStream()) { os.write(body.toString().getBytes(StandardCharsets.UTF_8)); }
        if (c.getResponseCode() / 100 != 2) return new JSONArray();
        String response = read(c.getInputStream());
        JSONArray out = new JSONArray();
        JSONArray lines = new JSONArray();
        // runQuery returns newline-delimited JSON objects.
        for (String line : response.split("\\n")) {
            if (line.trim().isEmpty()) continue;
            JSONObject o = new JSONObject(line);
            if (o.has("document")) out.put(o.getJSONObject("document"));
        }
        return out;
    }

    private String read(InputStream in) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
        StringBuilder b = new StringBuilder(); String line;
        while ((line = br.readLine()) != null) b.append(line).append('\n');
        return b.toString();
    }

    private String fieldString(JSONObject fields, String key, String fallback) {
        JSONObject f = fields.optJSONObject(key);
        if (f == null) return fallback;
        if (f.has("stringValue")) return f.optString("stringValue", fallback);
        if (f.has("integerValue")) return f.optString("integerValue", fallback);
        if (f.has("doubleValue")) return String.valueOf(f.optDouble("doubleValue"));
        if (f.has("booleanValue")) return String.valueOf(f.optBoolean("booleanValue"));
        return fallback;
    }

    private void showBookingAlert(String id, String customer, String service) {
        Intent accept = new Intent(this, BookingActionReceiver.class).setAction(ACTION_ACCEPT);
        accept.putExtra(EXTRA_BOOKING_ID, id);
        PendingIntent acceptPi = PendingIntent.getBroadcast(this, id.hashCode() ^ 11, accept,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        Intent reject = new Intent(this, BookingActionReceiver.class).setAction(ACTION_REJECT);
        reject.putExtra(EXTRA_BOOKING_ID, id);
        PendingIntent rejectPi = PendingIntent.getBroadcast(this, id.hashCode() ^ 12, reject,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        Intent open = new Intent(this, BookingAlertActivity.class);
        open.putExtra(EXTRA_BOOKING_ID, id); open.putExtra(EXTRA_CUSTOMER, customer); open.putExtra(EXTRA_SERVICE, service);
        PendingIntent openPi = PendingIntent.getActivity(this, id.hashCode() ^ 13, open,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));

        Notification n = new NotificationCompat.Builder(this, BOOKING_CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("🔔 New DHS Booking")
                .setContentText(customer + " • " + service)
                .setStyle(new NotificationCompat.BigTextStyle().bigText("Customer: " + customer + "\nService: " + service))
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setOngoing(true)
                .setAutoCancel(false)
                .setOnlyAlertOnce(false)
                .setContentIntent(openPi)
                .setFullScreenIntent(openPi, true)
                .addAction(new NotificationCompat.Action.Builder(0, "Accept", acceptPi).build())
                .addAction(new NotificationCompat.Action.Builder(0, "Reject", rejectPi).build())
                .build();
        notificationManager.notify(BOOKING_NOTIFICATION_ID, n);
        showBookingOverlay(id, customer, service);
        startBookingAlert();
    }

    private void startBookingAlert() {
        stopBookingAlert();
        try {
            alertPlayer = MediaPlayer.create(this, R.raw.dhs_booking_alert);
            if (alertPlayer != null) {
                alertPlayer.setLooping(true);
                alertPlayer.setVolume(1f, 1f);
                alertPlayer.start();
            }
        } catch (Exception ignored) {}
        vibrateLoop();
    }

    private void vibrateLoop() {
        if (vibrator == null || !vibrator.hasVibrator()) return;
        long[] pattern = new long[]{0, 500, 120, 500, 120, 900, 200};
        try {
            if (Build.VERSION.SDK_INT >= 26)
                vibrator.vibrate(VibrationEffect.createWaveform(pattern, 0));
            else vibrator.vibrate(pattern, 0);
        } catch (Exception ignored) {}
    }

    private void showBookingOverlay(String id, String customer, String service) {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) return;
        activeBookingId = id == null ? "" : id;
        handler.post(() -> {
            try {
                removeBookingOverlay();
                LinearLayout root = new LinearLayout(this);
                root.setOrientation(LinearLayout.VERTICAL); root.setPadding(34, 28, 34, 28); root.setGravity(Gravity.CENTER);
                GradientDrawable bg = new GradientDrawable(); bg.setColor(Color.WHITE); bg.setCornerRadius(36); root.setBackground(bg);
                TextView title = new TextView(this); title.setText("🔔  NEW DHS BOOKING"); title.setTextSize(21); title.setTextColor(Color.rgb(6,27,70)); title.setGravity(Gravity.CENTER); title.setTypeface(null,1);
                TextView details = new TextView(this); details.setText("\nCustomer: " + safeText(customer) + "\nService: " + safeText(service)); details.setTextSize(17); details.setTextColor(Color.rgb(23,36,60)); details.setPadding(0,12,0,22);
                Button accept = new Button(this); accept.setText("ACCEPT BOOKING"); accept.setTextSize(17);
                Button reject = new Button(this); reject.setText("REJECT"); reject.setTextSize(16);
                root.addView(title, new LinearLayout.LayoutParams(-1,-2)); root.addView(details,new LinearLayout.LayoutParams(-1,-2)); root.addView(accept,new LinearLayout.LayoutParams(-1,64)); root.addView(reject,new LinearLayout.LayoutParams(-1,58));
                accept.setOnClickListener(v -> handleOverlayAction(ACTION_ACCEPT, activeBookingId)); reject.setOnClickListener(v -> handleOverlayAction(ACTION_REJECT, activeBookingId));
                int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
                WindowManager.LayoutParams lp = new WindowManager.LayoutParams((int)(getResources().getDisplayMetrics().widthPixels*0.90f), WindowManager.LayoutParams.WRAP_CONTENT, type,
                    WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON, PixelFormat.TRANSLUCENT);
                lp.gravity=Gravity.CENTER; windowManager.addView(root,lp); bookingOverlay=root;
            } catch (Exception ignored) {}
        });
    }
    private String safeText(String s){ return s==null||s.isEmpty()?"Customer":s; }
    private void handleOverlayAction(String action,String id){
        stopBookingAlert(); removeBookingOverlay(); Intent i=new Intent(this,PartnerForegroundService.class); i.setAction(action); i.putExtra(EXTRA_BOOKING_ID,id);
        if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i);
    }
    private void removeBookingOverlay(){ handler.post(()->{ try{ if(bookingOverlay!=null&&windowManager!=null) windowManager.removeViewImmediate(bookingOverlay);}catch(Exception ignored){} bookingOverlay=null; }); }

    public void stopBookingAlert() {
        try { if (alertPlayer != null) { alertPlayer.stop(); alertPlayer.release(); } } catch (Exception ignored) {}
        alertPlayer = null;
        try { if (vibrator != null) vibrator.cancel(); } catch (Exception ignored) {}
        if (notificationManager != null) notificationManager.cancel(BOOKING_NOTIFICATION_ID);
    }

    private void updateBooking(String id, String status) {
        if (idToken.isEmpty() || uid.isEmpty()) return;
        try {
            String base = "https://firestore.googleapis.com/v1/projects/" + PROJECT + "/databases/(default)/documents/partnerJobs/" + URLEncoder.encode(id, "UTF-8");
            String json = "{\"fields\":{\"Stuts\":{\"stringValue\":\"" + status + "\"},\"partnerStatus\":{\"stringValue\":\"" + status + "\"},\"bookingStatus\":{\"stringValue\":\"" + status + "\"},\"workeruid\":{\"stringValue\":\"" + uid + "\"},\"partnerId\":{\"stringValue\":\"" + uid + "\"}}}";
            patch(base, json);
            try { patch("https://firestore.googleapis.com/v1/projects/" + PROJECT + "/databases/(default)/documents/bookings/" + URLEncoder.encode(id, "UTF-8"), json); } catch (Exception ignored) {}
        } catch (Exception ignored) {}
    }

    private void patch(String url, String json) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod("PATCH"); c.setConnectTimeout(7000); c.setReadTimeout(7000);
        c.setRequestProperty("Authorization", "Bearer " + idToken);
        c.setRequestProperty("Content-Type", "application/json"); c.setDoOutput(true);
        try (OutputStream os = c.getOutputStream()) { os.write(json.getBytes(StandardCharsets.UTF_8)); }
        c.getResponseCode();
    }

    @Override public void onLocationChanged(Location location) {}
    @Override public void onProviderEnabled(String provider) {}
    @Override public void onProviderDisabled(String provider) {}
    @Override public void onStatusChanged(String provider, int status, Bundle extras) {}

    @Override public void onDestroy() {
        running = false; handler.removeCallbacks(poller); stopTracking(); stopBookingAlert();
        executor.shutdownNow();
        super.onDestroy();
    }
    @Nullable @Override public IBinder onBind(Intent intent) { return null; }
}
